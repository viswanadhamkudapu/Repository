 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tackSxS.Installer-x64.msi | Pass   | 27MB     | 83.51          | 9.98        | 0.56        | 72.94         | 0           | 
