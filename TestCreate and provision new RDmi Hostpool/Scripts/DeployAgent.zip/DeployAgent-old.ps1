﻿<#
.SYNOPSIS
Deploys RD Infra agent into target VM

.DESCRIPTION
This script will get the registration token for the target pool name, copy the installer into target VM and execute the installer with the registration token and broker URI

If the pool name is not specified it will retreive first one (treat this as random) from the deployment.

.PARAMETER ComputerName
Required the FQDN or IP of target VM

.PARAMETER AgentInstaller
Required path to MSI installer file - must be <path>\Microsoft.RDInfra.RDAgent.*

.PARAMETER AgentBootServiceInstaller
Required path to MSI installer file

.PARAMETER SxSStackInstaller
Required path to MSI SxS stack installer file

.PARAMETER Session
Optional Powershell session into target VM

.PARAMETER AdminCredentials
Optional admin credentials that will be used to create remote powershell session to the VM

.PARAMETER $AdministratorUsername
Optional Administrator username that will be used to create remote powershell session to the VM

.PARAMETER $AdministratorLoginPassword
Optional Administrator password that will be used to create remote powershell session to the VM

.PARAMETER PoolName
Unique Pool name from which we need to get registration token

.PARAMETER StartAgent
Start the agent service (RdInfraAgent) immediately

.EXAMPLE

.\DeployAgent.ps1 -Computername 127.0.0.1 -AdministratorUsername "testadmin" -AgentInstaller 'Microsoft.RDInfra.RDAgent.Installer-x64' -SxSStackInstaller 
#>
#Requires -Version 4.0

Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$ComputerName,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentInstaller,
    
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentBootServiceInstaller,
	
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$SxSStackInstaller,
	
	[Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$EnableSxSStackScriptFile,

    [Parameter(Mandatory=$False)]
    [ValidateNotNullOrEmpty()]
    [System.Management.Automation.Runspaces.PSSession]$Session,

    [Parameter(Mandatory=$False)]
    [PSCredential] $AdminCredentials,

    [Parameter(Mandatory=$False, ParameterSetName='AdminCreds')]
    [String] $AdministratorUsername,
    [Parameter(Mandatory=$False, ParameterSetName='AdminCreds')]
    [SecureString] $AdministratorLoginPassword,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$TenantName,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$PoolName,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$RegistrationToken,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [bool]$StartAgent,
	[Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [bool]$rdshIs1809OrLater

)

function Test-IsAdmin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

# this will allow powershell connecting to the remote VM
if (Test-IsAdmin)
{
    Set-Item -Force -Verbose WSMan:\localhost\Client\TrustedHosts $ComputerName
}

#find the RDAgent Installer file (msi) in provided wildcard path
$agentMSI = Get-ChildItem $AgentInstaller | Select-Object -First 1

# Convert relative paths to absolute paths if needed
$AgentInstaller = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, $agentMSI.FullName))
if ((-not $AgentInstaller) -or (-not (Test-Path $AgentInstaller)))
{
    throw "RD Infra Agent Installer package is not found '$AgentInstaller'"
}

# Convert relative paths to absolute paths if needed
$AgentBootServiceInstaller = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, $AgentBootServiceInstaller))
if ((-not $AgentBootServiceInstaller) -or (-not (Test-Path $AgentBootServiceInstaller)))
{
    throw "RD Infra Agent Installer package is not found '$AgentBootServiceInstaller'"
}

# Convert relative paths to absolute paths if needed
$SxSStackInstaller = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, $SxSStackInstaller))
if ((-not $SxSStackInstaller) -or (-not (Test-Path $SxSStackInstaller)))
{
    throw "SxS Stack Installer package is not found '$SxSStackInstaller'"
}


Write-Output "Creating session to VM..."
if (!$Session) {
    if (!$AdminCredentials){
        if ($AdministratorUsername -and $AdministratorLoginPassword)
        {
            $AdminCredentials = New-Object System.Management.Automation.PSCredential ($AdministratorUsername, $AdministratorLoginPassword)
        } elseif ($AdministratorUsername)
        {
            $AdminCredentials = Get-Credential -Message "Enter credentials for admin user to '$ComputerName'" -UserName $AdministratorUsername
        } else
        {
            $AdminCredentials = Get-Credential -Message "Enter credentials for admin user to '$ComputerName'" -UserName "~\Administrator"
        }
    }

    if (!$AdminCredentials){
        throw "Administrator credentials to Windows Server Core VM are not specified"
    }

    $Session = New-PSSession –ComputerName $ComputerName -Credential $AdminCredentials
}

if (!$Session) {
    throw "cannot create session to target VM"
}

if (!$RegistrationToken)
{

    if (!$PoolName -or !$TenantName)
    {
        throw "Need either RegistrationToken or Tenant/Pool names specified"
    }

    Write-Output "Query broker for the registration token 'New-RdsRegistrationInfo'"
    $registrationInfo = New-RdsRegistrationInfo $TenantName $PoolName
    $RegistrationToken = $registrationInfo.Token
    Write-Output ("Got token: " + $RegistrationToken.Substring(0,20) + "...")
}

if (!$RegistrationToken)
{
    throw "No registration token specified"
}

$agent_installer_package_filename = [System.IO.Path]::GetFileName($AgentInstaller)
$bootloader_installer_package_filename = [System.IO.Path]::GetFileName($AgentBootServiceInstaller)
$sxsstack_installer_package_filename = [System.IO.Path]::GetFileName($SxSStackInstaller)

$vm_download_folder = Invoke-Command -Session $Session { [System.IO.Path]::GetTempPath() }

$vm_agent_deploy_path = Join-Path -path $vm_download_folder -childpath $agent_installer_package_filename
$vm_bootloader_deploy_path = Join-Path -path $vm_download_folder -childpath $bootloader_installer_package_filename
$vm_sxsstack_deploy_path = Join-Path -path $vm_download_folder -childpath $sxsstack_installer_package_filename

Write-Host "Copy Agent Installer into VM '$vm_agent_deploy_path' ..."
Copy-Item $AgentInstaller $vm_download_folder -ToSession $Session -Force
if(-not $?)
{
    $err = "Copy agent installer into VM Failed!"
    write-warning $err
    throw $err
}

Write-Host "Copy AgentBootLoader Installer into VM '$vm_bootloader_deploy_path' ..."
Copy-Item $AgentBootServiceInstaller $vm_download_folder -ToSession $Session -Force
if(-not $?)
{
    $err = "Copy AgentBootLoader installer into VM Failed!"
    write-warning $err
    throw $err
}


Write-Host "Copy SxS Stack Installer into VM '$vm_sxsstack_deploy_path' ..."
Copy-Item $SxSStackInstaller $vm_download_folder -ToSession $Session -Force

if(-not $?)
{
    $err = "Copy SxS Stack installer into VM Failed!"
    write-warning $err
    throw $err
}

Invoke-Command -Session $Session -scriptblock {
    #uninstall old packages  
    
    Write-Output "Uninstalling any previous versions of RDAgentBootLoader on VM"
    $bootloader_uninstall_status = Start-Process -FilePath "msiexec.exe" -ArgumentList "/x {A38EE409-424D-4A0D-B5B6-5D66F20F62A5}", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\AgentBootLoaderInstall.txt" -Wait -Passthru
    $sts = $bootloader_uninstall_status.ExitCode
    Write-Output "Uninstalling RDAgentBootLoader on VM Complete. Exit code=$sts"
  
    $oldAgents = (Get-WmiObject -Class Win32_Product | ? {($_.Name -eq 'Remote Desktop Services Infrastructure Agent')})

    foreach( $oldAgent in $oldAgents)
    {
        $oldVersion = $oldAgent.IdentifyingNumber
        Write-Output "Uninstalling old RD Infra Agent with version $oldVersion"
        $productCodeParameter = "/x " +  $oldAgent.IdentifyingNumber
        $agent_uninstall_status = Start-Process -FilePath "msiexec.exe" -ArgumentList $productCodeParameter, "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\AgentUninstall.txt" -Wait -Passthru
        $sts = $agent_uninstall_status.ExitCode
        Write-Output "Uninstalling RD Infra Agent on VM Complete. Exit code=$sts"
    }

    #install the package
    Write-Output "Installing RD Infra Agent on VM $using:vm_agent_deploy_path"

    $agent_deploy_status = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $using:vm_agent_deploy_path", "/quiet", "/qn", "/norestart", "/passive", "REGISTRATIONTOKEN=$using:RegistrationToken", "/l* C:\Users\AgentInstall.txt" -Wait -Passthru
    $sts = $agent_deploy_status.ExitCode
    Write-Output "Installing RD Infra Agent on VM Complete. Exit code=$sts"
    
    #install the package
    Write-Output "Installing RDAgent BootLoader on VM $using:vm_bootloader_deploy_path"

    $bootloader_deploy_status = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $using:vm_bootloader_deploy_path", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\AgentBootLoaderInstall.txt" -Wait -Passthru
    $sts = $bootloader_deploy_status.ExitCode
    Write-Output "Installing RDAgentBootLoader on VM Complete. Exit code=$sts"

    if ($using:StartAgent)
    {
        write-output "Starting service"
        Start-Service RDAgentBootLoader
    }

    #delete the installer
    Remove-Item -Path $using:vm_agent_deploy_path -Force -Recurse | Out-Null
}

$agent_deploy_status = Invoke-Command -Session $Session { $agent_deploy_status.ExitCode }


Invoke-Command -Session $Session -scriptblock {
# If the session host is Windows 1809 or later, run the enablesxsstack script	
	if($rdshIs1809OrLater){
	Write-Output "Enabling Built-in RD SxS Stack on VM $EnableSxSStackScript`n"
    $enablesxs_deploy_status = PowerShell.exe -ExecutionPolicy Unrestricted -File $EnableSxSStackScriptFile
    $sts = $enablesxs_deploy_status.ExitCode
    Write-Output "Enabling Built-in RD SxS Stack on VM Complete. Exit code=$sts`n"
	}
	else{
    #uninstall old package

    #Write-Output "Uninstalling any previous versions of SxS Stack on VM"
    #$agent_uninstall_status = Start-Process -FilePath "msiexec.exe" -ArgumentList "/x {5389488F-551D-4965-9383-E91F27A9F217}", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\WebDeployLog.txt" -Wait -Passthru
    #$sts = $agent_uninstall_status.ExitCode
    #Write-Output "Uninstalling RD Infra Agent on VM Complete. Exit code=$sts"

    #install the package
    Write-Output "Installing SxS Stack on VM $using:vm_sxsstack_deploy_path"

    $sxsstack_deploy_status = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $using:vm_sxsstack_deploy_path", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\SxSInstall.txt" -Wait -Passthru
    $sts = $sxsstack_deploy_status.ExitCode
    Write-Output "Installing RD SxS Stack on VM Complete. Exit code=$sts"


    #delete the installer
    Remove-Item -Path $using:vm_sxsstack_deploy_path -Force -Recurse | Out-Null
}

$sxsstack_deploy_status = Invoke-Command -Session $Session { $sxsstack_deploy_status.ExitCode }


$Session | Remove-PSSession -WhatIf:$False

# SIG # Begin signature block
# MIIn7gYJKoZIhvcNAQcCoIIn3zCCJ9sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBoiF9NT4LyNVVO
# kjdpAxsq3vd1UlqlP4fDWDtNoCvWOqCCEWUwggh3MIIHX6ADAgECAhM2AAAAgrsy
# RpV6geNbAAEAAACCMA0GCSqGSIb3DQEBCwUAMEExEzARBgoJkiaJk/IsZAEZFgNH
# QkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBDUyBDQSAwMTAe
# Fw0xODA3MTAxMzAyMzlaFw0xOTA3MTAxMzAyMzlaMCQxIjAgBgNVBAMTGU1pY3Jv
# c29mdCBBenVyZSBDb2RlIFNpZ24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQC6B/SG/b3ES+fa/jW7OzSAQxWlD1iY2W9U8MBJPBf23WR6PepYXO61z3JE
# H1MiAeAI8CA9XQCgUcrCXqQWJc6qEoSa2bScGXkApC7HukqFA+9cSdNe04QaS+S0
# RjWToYR09NjCCps6FLlmkwXZWgryrCGsAk48MggRMRNE2um1fSeEOWCLMHsFgWYN
# jwDxDsLpYhufbvvzwRBVy866Exm//HiOpR/vy1CEGZ37jT4LCklGIbvWJ7LuQ9Wj
# wZxj4JNwsx/AKwsDWweQ85Rfi+g3+FM7MCEyoJ98qEVTDApOZvUQEBxd771b97dR
# 5aKAfzc1H9oFDoh52jNmz3rDeWH/AgMBAAGjggWDMIIFfzApBgkrBgEEAYI3FQoE
# HDAaMAwGCisGAQQBgjdbAQEwCgYIKwYBBQUHAwMwPQYJKwYBBAGCNxUHBDAwLgYm
# KwYBBAGCNxUIhpDjDYTVtHiE8Ys+hZvdFs6dEoFgg93NZoaUjDICAWQCAQswggJ2
# BggrBgEFBQcBAQSCAmgwggJkMGIGCCsGAQUFBzAChlZodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpaW5mcmEvQ2VydHMvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDEpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDEu
# YW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUy
# MDAxKDEpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDIuYW1lLmdibC9haWEv
# QlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDEpLmNydDBS
# BggrBgEFBQcwAoZGaHR0cDovL2NybDMuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAx
# LkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDEpLmNydDBSBggrBgEFBQcwAoZG
# aHR0cDovL2NybDQuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDEpLmNydDCBrQYIKwYBBQUHMAKGgaBsZGFwOi8vL0NO
# PUFNRSUyMENTJTIwQ0ElMjAwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2Vy
# dmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1BTUUsREM9R0JM
# P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0
# aG9yaXR5MB0GA1UdDgQWBBSOTzmrWuq9s4lp8xOp1ano/K6DwDAOBgNVHQ8BAf8E
# BAMCB4AwUAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRp
# b25zIFB1ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzYxNjcrNDM4MDQyMIIB1AYDVR0f
# BIIByzCCAccwggHDoIIBv6CCAbuGPGh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2lpbmZyYS9DUkwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDEu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDIu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDMu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIYuaHR0cDovL2NybDQu
# YW1lLmdibC9jcmwvQU1FJTIwQ1MlMjBDQSUyMDAxLmNybIaBumxkYXA6Ly8vQ049
# QU1FJTIwQ1MlMjBDQSUyMDAxLENOPUJZMlBLSUNTQ0EwMSxDTj1DRFAsQ049UHVi
# bGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlv
# bixEQz1BTUUsREM9R0JMP2NlcnRpZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9v
# YmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludDAfBgNVHSMEGDAWgBQbZqIZ
# /JvrpdqEjxiY6RCkw3uSvTAfBgNVHSUEGDAWBgorBgEEAYI3WwEBBggrBgEFBQcD
# AzANBgkqhkiG9w0BAQsFAAOCAQEAkTjDgWcKF5AekFyhXDv4trHLi7qyl4UZrgpC
# mKDeftiGYPzlwtxKNBKToum6mWxLS5QvkurudtJBR26IPRXOCjwr8G4CpcC+4DOY
# cTm6xTaWUsJwINkhOFG0OozHXcfaAsdHXnm27Bi9cDcbBu+BTGQYYUfwpONZNoOt
# CZNzahokKX5DRPlevedCKMOlmcF9s28dFsD4He+4cn3fFzC9DcaNn0IwKAMOZl2B
# 5KpANKBRiAxfLOXunlBuJayl/3k5r78bxefxxrDq1rO0gGla1c8sVceaYLl5lB7N
# VgwLLWgLI1lkk2axdHo3W4D2TJBU+RG2PSmmPMzsILYs8oTcYTCCCOYwggbOoAMC
# AQICEx8AAAAUtMUfxvKAvnEAAAAAABQwDQYJKoZIhvcNAQELBQAwPDETMBEGCgmS
# JomT8ixkARkWA0dCTDETMBEGCgmSJomT8ixkARkWA0FNRTEQMA4GA1UEAxMHYW1l
# cm9vdDAeFw0xNjA5MTUyMTMzMDNaFw0yMTA5MTUyMTQzMDNaMEExEzARBgoJkiaJ
# k/IsZAEZFgNHQkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBD
# UyBDQSAwMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANVXgQLW+frQ
# 9xuAud03zSTcZmH84YlyrSkM0hsbmr+utG00tVRHgw40pxYbJp5W+hpDwnmJgicF
# oGRrPt6FifMmnd//1aD/fW1xvGs80yZk9jxTNcisVF1CYIuyPctwuJZfwE3wcGxh
# kVw/tj3ZHZVacSls3jRD1cGwrcVo1IR6+hHMvUejtt4/tv0UmUoH82HLQ8w1oTX9
# D7xj35Zt9T0pOPqM3Gt9+/zs7tPp2gyoOYv8xR4X0iWZKuXTzxugvMA63YsB4ehu
# SBqzHdkF55rxH47aT6hPhvDHlm7M2lsZcRI0CUAujwcJ/vELeFapXNGpt2d3wcPJ
# M0bpzrPDJ/8CAwEAAaOCBNowggTWMBAGCSsGAQQBgjcVAQQDAgEBMCMGCSsGAQQB
# gjcVAgQWBBSR/DPOQp72k+bifVTXCBi7uNdxZTAdBgNVHQ4EFgQUG2aiGfyb66Xa
# hI8YmOkQpMN7kr0wggEEBgNVHSUEgfwwgfkGBysGAQUCAwUGCCsGAQUFBwMBBggr
# BgEFBQcDAgYKKwYBBAGCNxQCAQYJKwYBBAGCNxUGBgorBgEEAYI3CgMMBgkrBgEE
# AYI3FQYGCCsGAQUFBwMJBggrBgEFBQgCAgYKKwYBBAGCN0ABAQYLKwYBBAGCNwoD
# BAEGCisGAQQBgjcKAwQGCSsGAQQBgjcVBQYKKwYBBAGCNxQCAgYKKwYBBAGCNxQC
# AwYIKwYBBQUHAwMGCisGAQQBgjdbAQEGCisGAQQBgjdbAgEGCisGAQQBgjdbAwEG
# CisGAQQBgjdbBQEGCisGAQQBgjdbBAEGCisGAQQBgjdbBAIwGQYJKwYBBAGCNxQC
# BAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMBIGA1UdEwEB/wQIMAYBAf8CAQAw
# HwYDVR0jBBgwFoAUKV5RXmSuNLnrrJwNp4x1AdEJCygwggFoBgNVHR8EggFfMIIB
# WzCCAVegggFToIIBT4YjaHR0cDovL2NybDEuYW1lLmdibC9jcmwvYW1lcm9vdC5j
# cmyGMWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2lpbmZyYS9jcmwvYW1lcm9v
# dC5jcmyGI2h0dHA6Ly9jcmwyLmFtZS5nYmwvY3JsL2FtZXJvb3QuY3JshiNodHRw
# Oi8vY3JsMy5hbWUuZ2JsL2NybC9hbWVyb290LmNybIaBqmxkYXA6Ly8vQ049YW1l
# cm9vdCxDTj1BTUVST09ULENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNl
# cyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPUFNRSxEQz1HQkw/Y2Vy
# dGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNzPWNSTERpc3Ry
# aWJ1dGlvblBvaW50MIIBqwYIKwYBBQUHAQEEggGdMIIBmTA3BggrBgEFBQcwAoYr
# aHR0cDovL2NybDEuYW1lLmdibC9haWEvQU1FUk9PVF9hbWVyb290LmNydDBHBggr
# BgEFBQcwAoY7aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraWluZnJhL2NlcnRz
# L0FNRVJPT1RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6Ly9jcmwyLmFt
# ZS5nYmwvYWlhL0FNRVJPT1RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6
# Ly9jcmwzLmFtZS5nYmwvYWlhL0FNRVJPT1RfYW1lcm9vdC5jcnQwgaIGCCsGAQUF
# BzAChoGVbGRhcDovLy9DTj1hbWVyb290LENOPUFJQSxDTj1QdWJsaWMlMjBLZXkl
# MjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPUFNRSxE
# Qz1HQkw/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRp
# b25BdXRob3JpdHkwDQYJKoZIhvcNAQELBQADggIBACi3Soaajx+kAWjNwgDqkIvK
# AOFkHmS1t0DlzZlpu1ANNfA0BGtck6hEG7g+TpUdVrvxdvPQ5lzU3bGTOBkyhGmX
# oSIlWjKC7xCbbuYegk8n1qj3rTcjiakdbBqqHdF8J+fxv83E2EsZ+StzfCnZXA62
# QCMn6t8mhCWBxpwPXif39Ua32yYHqP0QISAnLTjjcH6bAV3IIk7k5pQ/5NA6qIL8
# yYD6vRjpCMl/3cZOyJD81/5+POLNMx0eCClOfFNxtaD0kJmeThwL4B2hAEpHTeRN
# tB8ib+cze3bvkGNPHyPlSHIuqWoC31x2Gk192SfzFDPV1PqFOcuKjC8049SSBtC1
# X7hyvMqAe4dop8k3u25+odhvDcWdNmimdMWvp/yZ6FyjbGlTxtUqE7iLTLF1eaUL
# SEobAap16hY2N2yTJTISKHzHI4rjsEQlvqa2fj6GLxNj/jC+4LNy+uRmfQXShd30
# lt075qTroz0Nt680pXvVhsRSdNnzW2hfQu2xuOLg8zKGVOD/rr0GgeyhODjKgL2G
# Hxctbb9XaVSDf6ocdB//aDYjiabmWd/WYmy7fQ127KuasMh5nSV2orMcAed8CbIV
# I3NYu+sahT1DRm/BGUN2hSpdsPQeO73wYvp1N7DdLaZyz7XsOCx1quCwQ+bojWVQ
# TmKLGegSoUpZNfmP9MtSMYIV3zCCFdsCAQEwWDBBMRMwEQYKCZImiZPyLGQBGRYD
# R0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUwEwYDVQQDEwxBTUUgQ1MgQ0EgMDEC
# EzYAAACCuzJGlXqB41sAAQAAAIIwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEIN2uFM9VUGQEG1OTaQr4NBOZa4CslMh2S1FIS9sDiLt9
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAZSa1lWzMvAFd
# 49KEcXJsM6NtmmN8d9jMrdXIXy7TDuDIGItP/0Q5hu2StjhKBmSjvFukUYf8Oy2p
# UDQbIGofUTXkD3FwdsM0/S1hd9eUYscQGVlRWBb6fkqQzPMLKpH2GvHg7UrKceLb
# Y97EYS+ZonpxwLOc/XaJvdR5Z9sxLajTOTLAbGveXhsY9PrWD0tCX4vn+GRn2D+V
# MfWsWMJIT/A5Venwm8JGKlFK7Q+/1fQbPeiQxuKJqBs/yPe2mgXZ/Ua/xLVaETZ1
# N8cWbRH3kxc4Gpse92Hl+/osmvMt4DbhcHMaNQlNgZqMsnPfZNFUV80BSdWtO28f
# drF6iUbSzKGCE6cwghOjBgorBgEEAYI3AwMBMYITkzCCE48GCSqGSIb3DQEHAqCC
# E4AwghN8AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFUBgsqhkiG9w0BCRABBKCCAUME
# ggE/MIIBOwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCCmfXagxY0T
# kuxWQrW9YBdtbfKFUlzuf3YMB48E9AGFAgIGW4BJVkWKGBMyMDE4MDkxMTE4NTgx
# Mi41NjZaMAcCAQGAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRp
# b25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxMkI0LTJENUYtODdENDElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCDxMwggZxMIIEWaAD
# AgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBD
# ZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3
# MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWl
# CgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/Fg
# iIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeR
# X4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/Xcf
# PfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogI
# Neh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB
# 5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvF
# M2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAP
# BgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjE
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8E
# gZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcC
# AjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUA
# bgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Pr
# psz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOM
# zPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCv
# OA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v
# /rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99
# lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1kl
# D3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQ
# Hm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30
# uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp
# 25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HS
# xVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi6
# 2jbb01+P3nSISRIwggTxMIID2aADAgECAhMzAAAA5U5FZ2pydNHMAAAAAADlMA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4
# MDgyMzIwMjcwOVoXDTE5MTEyMzIwMjcwOVowgcoxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9w
# ZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjEyQjQtMkQ1Ri04N0Q0
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5hpiEtynjR5MW3P7ajgcmIdaRG0UGgqw
# d11cFHtyWc+9pydi3AD87lJwtpuBUbdJFxSNHzQ38J5KkD6u9C6fraT9JYqAMxIe
# th+DthZETmHBRenQUM/GRqdXHii09hBW7hrFQYMyAJ3u8UWOKKQtZ9jWJEenI+JE
# 8Nyi+hpiWuoxlCfGvRR5FjF/MuIvSgw1hZNoMMRmry79Rl2cLpGtefrWaNS8+fiP
# Xumm3QycjF4Vw4uptLo5Acwu7kHL01BWLRTrgPUKejfWF7CAbt+CCummNfuktExl
# Lx27zxbIXNSlYhz9fewZxKrMQJYUmbmdFbM0iswG7dNaMA4ugIKwyQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFBDWWeBNHB+P4owgcPNICFxzDmaxMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBADFjhrYM2/7Tcg9UJmtNTzMTknE+MaBnRZg3U3iKlcQ9
# bTTCFQOhHyU5QH9AnaK1GjTzbdybJSBtzhsAl1VKhcCt3JnoW2U0S8n0hjkl/tKt
# sr6dJZU8Uc6/fnpWcG9AjM/SUGy+zdp5AnkZV2zvKJ9bypjV0WZ+uN3UwoVwIAJk
# lfugp9UTk1VhOfWPSk+PYdN9a8KetJc/hqof5fU3hX+EJt00sMbhMqdB60p5JEXt
# aRlClcHAMwj2mHKgK73iGikraNPmRf7pitjLNgFj1B678T1bRguBIkaRjDJ8rLTQ
# y3cd458ArntDXildRdLrZOxOtw3jc1+4qP7hLoAiGDGhggOlMIICjQIBATCB+qGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMG
# A1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046MTJCNC0yRDVGLTg3RDQxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJBgUrDgMCGgUAAxUAptMAMmWCvsRQyOxF
# 9iTnjiEmn0OggdowgdekgdQwgdExCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5DaXBoZXIgTlRTIEVTTjoyNjY1LTRDM0YtQzVERTErMCkGA1UE
# AxMiTWljcm9zb2Z0IFRpbWUgU291cmNlIE1hc3RlciBDbG9jazANBgkqhkiG9w0B
# AQUFAAIFAN9CDKYwIhgPMjAxODA5MTEwOTQzMDJaGA8yMDE4MDkxMjA5NDMwMlow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA30IMpgIBADAHAgEAAgIK2DAHAgEAAgIZ
# OjAKAgUA30NeJgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMBoAow
# CAIBAAIDFuNgoQowCAIBAAIDB6EgMA0GCSqGSIb3DQEBBQUAA4IBAQDKNP1yLcPb
# 5sO6RW8+m/ssh2O+7HLpsIzJ373Wd1NrutbTSXDvyM2m2xINqIGk600jo1tBIPBc
# g6POVBAuibVPKL+iO802zP7Mi/oPUxsNj5ru1tGgoBPOEKTEy0OfFogm7C6nia3O
# Zi+tl7ULNaMfY6S7fwBrQv3aM1KfowrUYoKGB0hA5gulQ4LqTk0TI75ZPPnU+ur6
# 5P53E3UpI/THkwTOvPUnDTECT6XbUoWUhSIjk+lidvLYroOHzsAk9/TR+O0RacuY
# rTOk6bxtIFyhqvZjzFEOvKEybNvpsuGnUwTnqTGezny6op0cG/EzzOy7AC+LvHiZ
# xqVSR9h2kD1gMYIC9TCCAvECAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAADlTkVnanJ00cwAAAAAAOUwDQYJYIZIAWUDBAIBBQCgggEyMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgiahOvALO
# +lPO6elk4DfmSZOB84gEWBaoWsZPqEHq12swgeIGCyqGSIb3DQEJEAIMMYHSMIHP
# MIHMMIGxBBSm0wAyZYK+xFDI7EX2JOeOISafQzCBmDCBgKR+MHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA5U5FZ2pydNHMAAAAAADlMBYEFJzM1XEz
# Dfl+cpDQ0aYnfX0dk9a6MA0GCSqGSIb3DQEBCwUABIIBAHwaRS62HwlwVQgpZsV6
# dR0OuEsVRKluYUy1osD7i/mhZvDp66FEm5wW1OJn8n4rrSURZl+nENDQWBxlRUHq
# I7/QBXawILS9HAO1lQoGRnpa+I8786M2uKbeIFw+/HJ9LC99YJMa8xlZCiAWaVvR
# kwJGT9IhqknVC9A5KrBRuYPPcyaALOAJR7OQsv676LgWcTV1lpoCCueikRPHxXYS
# MKmKGPFG0ZXPZ+MTXMs8AFpSNw/YIrrST/exYPFd/skat59oSPe5t87LT+y16X9L
# pQZgoJM/phwlHpCozdwTUtcjaE/zULEbmzQ32WR/2HJKJw5zqiL7/bajDVdafZuD
# /0Y=
# SIG # End signature block
