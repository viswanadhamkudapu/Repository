 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tLoader.Installer-x64.msi | Pass   | 400KB    | 28.62          | 1.54        | 0.51        | 26.53         | 0           | 
