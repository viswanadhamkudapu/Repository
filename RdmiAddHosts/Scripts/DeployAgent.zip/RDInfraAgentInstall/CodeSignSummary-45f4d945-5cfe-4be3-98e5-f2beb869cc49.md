 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | staller-x64-1.0.0.930.msi | Pass   | 14.03MB  | 148.46         | 6.1         | 0.52        | 141.8         | 0           | 
