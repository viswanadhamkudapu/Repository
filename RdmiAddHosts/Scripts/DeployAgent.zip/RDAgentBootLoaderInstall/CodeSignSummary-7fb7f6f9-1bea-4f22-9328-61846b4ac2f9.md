 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | tLoader.Installer-x64.msi | Pass   | 364KB    | 448.54         | 1.52        | 0.5         | 446.49        | 0           | 
