# Create MSFT-WVD-SAAS-UX Environment

Deploy the web app to your azure environment.

Click the button below to deploy:

[![Deploy to Azure](https://azuredeploy.net/deploybutton.png)](https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2FRDS-Templates%2Fwvd-mgmt-ux-0819%2Fwvd-templates%2Fwvd-management-ux%2Fdeploy%2FmainTemplate.json)

## Azure resouces deployed
- Azure App Services (Web App &  API App)
- Azure App Service Service Plan (S1- Standard)