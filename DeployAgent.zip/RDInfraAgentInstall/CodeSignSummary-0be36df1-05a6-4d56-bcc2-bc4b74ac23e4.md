 | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | taller-x64-1.0.0.1162.msi | Pass   | 17.24MB  | 61.04          | 8.93        | 0.48        | 51.6          | 0           | 
